import json

def handler(event, context):
    print(f"Campaign hook triggered: {json.dumps(event)}")
    return {
        'statusCode': 200,
        'body': json.dumps('Campaign hook processed successfully')
    }
